$(document).ready(function () {
  $('.slider-content').slick({
    slidesToShow: 4,
    slidesToScroll: 4,
    arrows: true,
    responsive: [{
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000
      }
    }, {
      breakpoint: 800,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        autoplay: true,
        autoplaySpeed: 3000
      }
    }]
  });

  $('.slider-info').hover(function() {
    var infoBlock = $(this).find('.info-block'); 
    var infoBlockOther = $('.slider-info .info-block'); 
    
    if (infoBlock.hasClass('open')) {
      infoBlockOther.removeClass('open');
    } else {
      infoBlock.addClass('open');
    }
  });

  $(window).scroll(function() {
    var scrollPos = $(window).scrollTop();
    if (scrollPos < 500) {
      $('.backtotop').addClass('hidden');    
    }    
    if (scrollPos >= 500) {
      $('.backtotop').removeClass('hidden');    
    } 
  });
  $('.backtotop').click(function() {
    $("html, body").animate({ scrollTop: 0 }, 1000);
    return false;
  });
});